﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;

namespace code
{

    class Program
    {
        static void Main(string[] args)
        {
            string choice = "";

            while (choice != "3")
            {
                OutputMenu();
                choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        PlayGame();
                        break;

                    case "2":
                        DisplayHighScore();
                        break;

                    case "3":
                        Console.WriteLine("Goodbye");
                        break;

                    default:
                        Console.WriteLine("Invalid");
                        break;
                }
            }
        }

        static void OutputMenu()
        {
            Console.WriteLine("1  Play Game");
            Console.WriteLine("2  Display High Score");
            Console.WriteLine("3  Quit");

            Console.Write("Enter choice: ");
        }



        static void PlayGame()
        {

            StreamReader sr;
            StreamWriter sw;



            string[] HighScorestr = new string[11];
            sr = new StreamReader("High Scores.txt");
            for (int i = 0; i < 11; i++)
            {
                HighScorestr[i] = sr.ReadLine();

            }
            sr.Close();
            Console.WriteLine();

            string[] highnamestr = new string[11];
            sr = new StreamReader("High Names.txt");
            for (int q = 0; q < 11; q++)
            {
                highnamestr[q] = sr.ReadLine();

            }
            sr.Close();
            int[] highscoreval = new int[11];

            for (int q = 0; q < 11;q++)
            {
                highscoreval[q] = int.Parse(HighScorestr[q]);                
            }

            string name;
            int randNum = 0;
            int randum2 = 0;
            char letter;
            string letter1;
            bool good = false;
            Random rd = new Random();
            Stopwatch Time = new Stopwatch();
            Console.WriteLine(" ");
            Console.WriteLine("========================================================================================================");
            Console.WriteLine("In this game a random capital letter will appear, when it does type the same letter into the box,, ");
            Console.WriteLine("If your time is the fastest on record then it will be saved along with your name in a seperate file, ");
            Console.WriteLine("The letter can take up to 5 seconds to appear and as little as 0.001. ");
            Console.WriteLine("========================================================================================================");
            Console.WriteLine("enter name (5 Letters long): ");
            name = Console.ReadLine();
            while (good == false)
            {
                Console.WriteLine(" ");
                Console.WriteLine("please re-enter name ");
                name = Console.ReadLine();


                if (name.Length == 5)
                {
                    Console.WriteLine("Welcome, " + name);
                    Console.WriteLine();
                    good = true;
                }
                else if (name.Length > 5)
                {
                    Console.WriteLine("Name is too long... Try again");
                    Console.WriteLine();
                }
                else if (name.Length < 5)
                {
                    Console.WriteLine("Name is too short... try again");
                    Console.WriteLine();
                }

            }
            //collecting and storing name

            Console.WriteLine("Starting . . .");
            randNum = rd.Next(65, 91);
            letter = (char)randNum;
            //generate random number which corresponds to a letter and store it

            randum2 = rd.Next(1, 5000);

            System.Threading.Thread.Sleep(randum2);
            Time.Start();
            Console.WriteLine(" ");
            Console.WriteLine(" ");
            Console.WriteLine(letter);
            Console.WriteLine(" ");
            letter1 = Console.ReadLine();

            if (letter1 == letter.ToString())
            {
                Time.Stop();
                Console.WriteLine(" ");
                Console.WriteLine("Time elapsed: {0}", Time.ElapsedMilliseconds + " ms");
                Console.WriteLine("Name: " + name);
                Console.WriteLine(" ");
                
                highscoreval[10] = (int)Time.ElapsedMilliseconds;
                highnamestr[10] = name;

                int length = highscoreval.Length;
                int temp4 = highscoreval[0];
                string temp5 = highnamestr[0];
                 
                int[] arr = { 800, 11, 50, 771, 649, 770, 240, 9 };

                int temp = 80085;
                string tenp = "test";

                for (int write = 0; write < highscoreval.Length; write++)
                {
                    for (int sort = 0; sort < highscoreval.Length - 1; sort++)
                    {
                        if (highscoreval[sort] > highscoreval[sort + 1])
                        {
                            temp = highscoreval[sort + 1];
                            highscoreval[sort + 1] = highscoreval[sort];
                            highscoreval[sort] = temp;

                            tenp = highnamestr[sort + 1];
                            highnamestr[sort + 1] = highnamestr[sort];
                            highnamestr[sort] = tenp;

                        }
                    }
                }

                Console.WriteLine();
                Console.WriteLine("Rank || Name || Time");
                for (int k = 0; k < highnamestr.Length-1; k++)
                {
                    if (k < 9)
                    {
                        Console.Write((k + 1) + "    || " + highnamestr[k] + "  ||  " + highscoreval[k]);
                        Console.WriteLine();
                    }
                    else
                    {
                        Console.Write((k + 1) + "   || " + highnamestr[k] + "  ||  " + highscoreval[k]);
                    }
                }
                Console.WriteLine();

                sw = new StreamWriter("High Scores.txt");

                for (int q = 0; q < length; q++)
                {
                    sw.WriteLine(highscoreval[q]);
                }
                sw.Close();

                sw = new StreamWriter("High Names.txt");

                for (int q = 0; q < length; q++)
                {
                    sw.Write(highnamestr[q]);
                    sw.WriteLine();
                }
                sw.Close();

            }
            else
            {
                Console.WriteLine(" ");
                Console.WriteLine("Wrong, Loser.");
                Console.WriteLine(" ");
            }
            return;
        }

        static void DisplayHighScore()
        {

            StreamReader sr;
           
            string[] HighScores = new string[12];
            sr = new StreamReader("High Scores.txt");
            for (int i = 0; i < 10; i++)
            {
                HighScores[i] = sr.ReadLine();
            }
            sr.Close();


            string[] Highnames = new string[12];
            sr = new StreamReader("High Names.txt");
            for (int q = 0; q < 10; q++)
            {
                Highnames[q] = sr.ReadLine();
            }
            sr.Close();

            //somehow store and load a binary file of high scores
            //hoo boy do i have something to tell you old green text note :)
            Console.WriteLine(" ");
            Console.WriteLine("==========================================");
            Console.WriteLine("Here are the high scores from the game,");
            Console.WriteLine("All scores are in ms");
            Console.WriteLine("==========================================");
            Console.WriteLine(" ");

            Console.WriteLine("Rank || Name || Time");
            for (int k = 0; k < HighScores.Length - 2; k++)
            {
                if (k <9)
                { 
                    Console.Write((k + 1) + "    || " + Highnames[k] + "  ||  " + HighScores[k]);
                    Console.WriteLine();
                }
                else
                {
                    Console.Write((k + 1) + "   || " + Highnames[k] + "  ||  " + HighScores[k]);
                }
            }
            Console.WriteLine();
        }

    }




}
